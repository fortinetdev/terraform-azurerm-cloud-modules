import requests
import os
import time
import random
import string
from .utils import debug_print

LOGIN_URL = "https://customerapiauth.fortinet.com/api/v1/oauth/token/"
API_URL = "https://support.fortinet.com/ES/api/fortiflex/v2/"


class FortiFlex:
    def __init__(self, username="", password="", access_token="", task_name=""):
        self.task_name = task_name
        if not task_name:
            self.task_name = "AZURE-" + "".join(
                random.choice(string.ascii_uppercase + string.digits) for _ in range(8)
            )
        self.access_token = (
            access_token if access_token else self.get_access_token(username, password)
        )

    def send_request(self, url: str, data: dict):
        headers = {"Authorization": "Bearer {}".format(self.access_token)}
        request_url = os.path.join(API_URL, url)
        response = requests.post(request_url, json=data, headers=headers)
        response_json = response.json()
        if response.status_code != 200:
            # Report a warning rather than an error.
            error_msg = response_json.get("message", "")
            error_report = ""
            if "errors" in response_json:
                error_report = response_json["errors"]
            elif "error" in response_json:
                error_report = response_json["error"]
            debug_print(
                "Receive code {} when sending a request to {}.\nError msg:{}\nError detail:{}.".format(
                    response.status_code, url, error_msg, error_report
                )
            )
        return response_json

    def get_access_token(self, username: str, password: str):
        data = {
            "username": username,
            "password": password,
            "client_id": "flexvm",
            "grant_type": "password",
        }
        response = requests.post(LOGIN_URL, json=data)
        if response.status_code != 200:
            raise RuntimeError(
                f"Can't login fortiflex, please check your username and password {response}, {response.url}, {response.status_code}"
            )
        access_token = response.json().get("access_token", "")
        return access_token

    def get_entitlements(self, config_id: int):
        data = {"configId": config_id}
        response = self.send_request("entitlements/list", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list

    def get_entitlement(
        self, config_id: int, serial_number: str = "", description: str = ""
    ):
        data = {"configId": config_id}
        if serial_number:
            data["serialNumber"] = serial_number
        if description:
            data["description"] = description
        response = self.send_request("entitlements/list", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list[0] if entitlements_list else {}

    def activate_entitlement(self, serial_number: str):
        data = {"serialNumber": serial_number}
        response = self.send_request("entitlements/reactivate", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list[0] if entitlements_list else {}

    def stop_entitlement(self, serial_number: str):
        data = {"serialNumber": serial_number}
        response = self.send_request("entitlements/stop", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list[0] if entitlements_list else {}

    def update_entitlement(
        self, serial_number: str, config_id: int = None, description: str = None
    ):
        data = {"serialNumber": serial_number}
        if description is not None:
            data["description"] = description
        if config_id is not None:
            data["configId"] = config_id
        response = self.send_request("entitlements/update", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list[0] if entitlements_list else {}

    def refresh_token(self, serial_number: str):
        data = {"serialNumber": serial_number}
        response = self.send_request("entitlements/vm/token", data)
        entitlements_list = response.get("entitlements", [])
        return entitlements_list[0] if entitlements_list else {}

    def retrieve_unused_entitlement(
        self, config_id: int, mode: str = "use_active", concurrent_mode: bool = False
    ):
        """
        Search through a list of entitlements and return an entitlement based on the specified mode.
        If no target is found, it will return an empty dict.

        Args:
            config_id (int): The ID of entitlement's configuration.
            mode (str, optional): The mode of operation.
                                  "use_active" for returning one active and unused entitlement.
                                  "use_stopped" for activating and returning one entitlement that is expired, stopped, or pending.
                                  Defaults to "use_active".
            concurrent_mode (bool, optional): If True, performs a check to ensure the entitlement can be used,
                                              and if not, continues to the next. Defaults to False.

        Returns:
            dict: The entitlement that matches the criteria based on the mode and concurrent_mode,
                  or an empty dictionary if no matching entitlement is found.
        """
        assert mode in [
            "use_active",
            "use_stopped",
        ], "mode should be use_active or use_stopped"
        entitlements_list = self.get_entitlements(config_id)
        for entitlement in entitlements_list:
            if mode == "use_active":
                if (
                    entitlement["status"] in ["ACTIVE", "PENDING"]
                    and entitlement["tokenStatus"] == "NOTUSED"
                ):
                    # If concurrent_mode, preempt it, wait for 1 second, and check it again
                    if concurrent_mode:
                        if entitlement["description"]:
                            continue
                        is_available, entitlement = self.is_entitlement_available(
                            entitlement
                        )
                        if not is_available:
                            continue
                    return entitlement
            elif mode == "use_stopped":
                if entitlement["status"] in ["EXPIRED", "STOPPED"]:
                    if concurrent_mode:
                        if entitlement["description"] != "":
                            continue
                        is_available, entitlement = self.is_entitlement_available(
                            entitlement
                        )
                        if not is_available:
                            continue
                    new_entitlement = self.activate_entitlement(
                        entitlement["serialNumber"]
                    )
                    new_entitlement = self.refresh_token(entitlement["serialNumber"])
                    return new_entitlement
        return {}

    def release_used_entitlement(
        self,
        serial_number: str,
        config_id: int,
        mode: str = "use_stopped",
        concurrent_mode: bool = False,
    ):
        """
        Release used entitlement. It will perform the opposite operation of function retrieve_unused_entitlement.

        Args:
            serial_number (str): Entitlement's serial number.
            config_id (integer): The ID of entitlement's configuration.
            mode (str, optional): The mode of operation in retrieve_unused_entitlement.
                                  This function will do the reverse operation.
            concurrent_mode (bool, optional): The mode of operation in retrieve_unused_entitlement.
                                              This function will do the reverse operation.
        Returns:
            dict: The status of the released entitlement.
        """
        assert mode in [
            "use_active",
            "use_stopped",
        ], "mode should be use_active or use_stopped"
        entitlement = self.get_entitlement(config_id, serial_number=serial_number)
        if entitlement["status"] != "STOPPED":
            self.stop_entitlement(serial_number)
        if concurrent_mode:
            self.update_entitlement(serial_number, config_id=config_id, description="")
        return self.refresh_token(serial_number)

    def is_entitlement_available(self, entitlement: dict):
        """
        Check if the specified entitlement is available.

        Args:
            entitlement (dict): The entitlement dictionary containing at least 'serialNumber' and 'configId'.

        Returns:
            bool: True if no other tasks are simultaneously trying to require this entitlement.
        """
        serial_number = entitlement["serialNumber"]
        config_id = entitlement["configId"]
        self.update_entitlement(
            serial_number, config_id=config_id, description=self.task_name
        )
        time.sleep(1)
        entitlement = self.get_entitlement(config_id, serial_number=serial_number)
        if entitlement["description"] == self.task_name:
            return True, entitlement
        return False, {}

