import requests
import time
import base64
from requests.packages.urllib3.exceptions import InsecureRequestWarning

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
from .utils import debug_print
from urllib.parse import quote


class FortiGateConfig:
    def __init__(
        self,
        host_ip,
        instance_id,
        login_port="",
        instance_name="",
        max_retry=6,
        username="admin",
        password="",
        debug=True,
    ):
        self.host_ip = host_ip
        self.login_port = str(login_port)
        self.cookie = ""
        self.csrf_token = ""
        self.instance_id = instance_id
        self.instance_name = instance_name
        if not instance_name:
            self.instance_name = instance_id
        self.timeout = 5
        self.max_retry = max_retry + 1
        self.username = username
        self.password = quote(password)
        self.debug = debug

    def log(self, error_str):
        if self.debug:
            debug_print("[{}] {}".format(self.instance_name, error_str))

    def send_request(self, url, header, data={}, request_name=""):
        retry_time = 0
        while retry_time < self.max_retry:
            retry_time += 1
            self.log(
                "Task {} | Attempt {} | URL {} | Header {} | DATA {}".format(
                    request_name, retry_time, url, header, data
                )
            )
            try:
                response = requests.post(
                    url, headers=header, json=data, verify=False, timeout=self.timeout
                )
                self.log(
                    "Task {} | Attempt {} | Response Code {} | Text {} | Header {}".format(
                        request_name,
                        retry_time,
                        response.status_code,
                        str(response.text).replace("\n", ""),
                        str(response.headers).replace("\n", ""),
                    )
                )
                # If 401, try to relogin and get net cookie
                if response.status_code == 401:
                    if request_name != "login":
                        self.log("sleep 20s and re-login".format(request_name))
                        time.sleep(20)
                        self.login()
                        continue
                return True, response
            except Exception as e:
                if retry_time == self.max_retry:
                    raise Exception(
                        "[{}] request {} fail {} time(s), {}, stop function.".format(
                            self.instance_id, request_name, retry_time, e
                        )
                    )
                self.log(
                    "request {} fail {} time(s), {}, sleep 20 seconds and retry.".format(
                        request_name, retry_time, e
                    )
                )
                time.sleep(20)
        return False, requests.Response()

    def get_url(self, path):
        login_port = ""
        if self.login_port:
            login_port = ":" + self.login_port
        if not path.startswith("/"):
            path = "/" + path
        return "https://" + self.host_ip + login_port + path

    def get_cookie(self, header):
        cookie_data = ""
        for key in header:
            if key.lower() == "set-cookie":
                cookie_data = header[key]
                break
        cookie_list = cookie_data.split(",")
        cookie_list = [item.split(";")[0] for item in cookie_list]
        for item in cookie_list:
            if "ccsrftoken" in item:
                self.csrf_token = item.split('"')[1]
        self.cookie = ";/n".join(cookie_list)

    def login(self, username="", password=""):
        if not username:
            username = self.username
        if not password:
            password = self.password
        LOGIN_FORMAT = "logincheck?username={username}&secretkey={password}"
        url = self.get_url(
            LOGIN_FORMAT.format(username=username, password=quote(password))
        )
        header = {"Content-Type": "application/json"}
        status, response = self.send_request(url, header, request_name="login")
        if response.status_code != 200:
            self.log("Cannot login {}".format(response.text))
            return False, response
        self.log("login {} {} {}".format(username, password, url))
        self.get_cookie(response.headers)
        self.log("login cookie {} {}".format(self.cookie, self.csrf_token))
        return status, response

    def upload_license(self, license_source, license_data):
        if license_source not in ["none", "fortiflex", "file"]:
            return False, self._generate_response(
                "variable LICENSE_SOURCE should be 'none', 'fortiflex' or 'file'."
            )
        if license_source == "none":
            return True, self._generate_response(
                "variable LICENSE_SOURCE is 'none', no need to upload license."
            )
        status, response = self.login()
        if not status:
            return False, response
        header = {
            "Content-Type": "application/json",
            "Cookie": self.cookie,
            "X-CSRFTOKEN": self.csrf_token,
        }
        if license_source == "fortiflex":
            body = {"token": license_data}
            url = self.get_url("/api/v2/monitor/system/vmlicense/download")
            return self.send_request(
                url, header, data=body, request_name="upload_license_fortiflex"
            )
        elif license_source == "file":
            body = {
                "file_content": base64.b64encode(license_data.encode("ascii")).decode(
                    "ascii"
                )
            }
            url = self.get_url("/api/v2/monitor/system/vmlicense/upload")
            return self.send_request(
                url, header, data=body, request_name="upload_license_file"
            )
        return False, requests.Response()

    def upload_config(self, config_data):
        status, response = self.login()
        if not status:
            return False, response
        header = {
            "Content-Type": "application/json",
            "Cookie": self.cookie,
            "X-CSRFTOKEN": self.csrf_token,
        }
        encoded_config_data = base64.b64encode(config_data.encode("ascii")).decode(
            "ascii"
        )
        body = {"filename": "config_data.conf", "file_content": encoded_config_data}
        url = self.get_url("/api/v2/monitor/system/config-script/upload")
        status, response = self.send_request(
            url, header, data=body, request_name="upload_config"
        )
        return status, response

    def change_init_password(self, new_password="", old_password=""):
        if not old_password:
            old_password = self.instance_id
        if not new_password:
            new_password = self.password
        url = self.get_url("/api/v2/authentication")
        header = {"Content-Type": "application/json"}
        body = {
            "username": "admin",
            "secretkey": old_password,
            "ack_pre_disclaimer": True,
            "ack_post_disclaimer": True,
            "new_password1": new_password,
            "new_password2": new_password,
            "request_key": True,
        }
        status, response = self.send_request(
            url, header, data=body, request_name="change_password"
        )
        if response.status_code != 200:
            self.log("change password error {}".format(response.status_code))
            return False, response
        response_json = response.json()
        session_key = response_json.get("session_key", "")
        if not session_key:
            self.log(
                "can't get session key when changing password {}".format(response_json)
            )
            return False, response
        body = {"session_key": session_key}
        self.send_request(url, header, data=body, request_name="change_password_logout")
        return status, response

    def _generate_response(self, response_text):
        response = requests.Response()
        response._content = response_text.encode("utf-8")
        response.encoding = "utf-8"
        return response
